package agent1t;
import jade.core.Agent;

public class MyAgent1 extends Agent {

}
